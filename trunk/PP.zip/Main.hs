module Main where

import Graphics.UI.Gtk

import LogicGate
import Levels

main = do
    initGUI
    window <- windowNew
    canvas <- drawingAreaNew
    let w = 600
    let h = 400
    set window [containerChild := canvas,
	containerBorderWidth := 5,
	windowTitle := "Test"]

    canvas `onSizeRequest` return (Requisition w h)

    canvas `onExpose` updateCanvas canvas
    
    onDestroy window mainQuit
    widgetShowAll window
    mainGUI


updateCanvas :: DrawingArea -> Event -> IO Bool
updateCanvas canvas (Expose {eventArea = rect}) = do
    win <- widgetGetDrawWindow canvas
    (width, height) <- widgetGetSize canvas
    gc <- gcNew win

    gcSetValues gc $ newGCValues {
	    foreground = Color 65535 0 0
    }
    drawLine win gc (0, 0) (width, 0)

    gcSetValues gc $ newGCValues {
	    foreground = Color 0 65535 0
    }
    drawLine win gc (0, 0) (0, height)

    gcSetValues gc $ newGCValues {
	    foreground = Color 0 0 0
    }

    drawGates win gc $ getGateRepresentation width height instanceOfProblem
    drawWires win gc $ getWires width height instanceOfProblem

    return True


