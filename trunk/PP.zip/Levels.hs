module Levels where

import Data.List
import Graphics.UI.Gtk

import LogicGate

data GateLevel
    = GateLevel {
		glValue	::  String,
		glType	::  String,
		glVars	::  [String]
    } deriving Show

instanceOfProblem = [
    (GateLevel "E" "XOR" ["alfa", "beta"]),
    (GateLevel "alfa" "OR" ["a", "gamma"]),
    (GateLevel "beta" "AND" ["delta", "epsilon"]),
    (GateLevel "gamma" "AND" ["phi", "epsilon"]),
    (GateLevel "delta" "AND" ["a", "c"]),
    (GateLevel "epsilon" "AND" ["b", "d"]),
    (GateLevel "phi" "XOR" ["a", "c"])]

getLevel0 :: [GateLevel] -> [String]
getLevel0 l = (getOutputs l) \\ (getInputs l)

getOutputs :: [GateLevel] -> [String]
getOutputs [] = []
getOutputs (x : xs) = nub $ (glVars x) ++ (getOutputs xs)

getInputs :: [GateLevel] -> [String]
getInputs [] = []
getInputs (x : xs) = (glValue x) : (getInputs xs)

getNextLevelInside :: [GateLevel] -> [String] -> [String]
getNextLevelInside ioP metBefore = nub (metBefore ++ ( map glValue $ filter f ioP))
    where
	f = \x -> (glVars x) `isSubset` metBefore
	isSubset xs ys = all (\x -> x `elem` ys) xs

getLevels :: [GateLevel] -> [[String]]
getLevels ioP = reduce . accumulate f $ [getLevel0 ioP]
    where
	f = getNextLevelInside ioP
	accumulate f l = 
		if (length l1) /= (length l2)
	        then accumulate f $ l ++ [l2]
		else l
	    where
		l1 = last l
	        l2 = f l1
	reduce l = map diff $ zip ([] : l) l
	    where
		diff x = (snd x) \\ (fst x)

getWires :: Int -> Int -> [GateLevel] -> [(Point, Point)]
getWires ww hw l 
    = (getInputWires ww hw l)
    ++ (getOutputWires ww hw l) 
    ++ (getMidWires ww hw l)
--    ++ (getGateWires ww hw l)

getInputWires :: Int -> Int -> [GateLevel] -> [(Point, Point)]
getInputWires ww hw l 
	= zip start end
    where
	start = zip (repeat 0) [eps, 2*eps .. n * eps]
	end = zip (repeat w) [eps, 2*eps .. n * eps]
	n = length . getLevel0 $ l
	eps = truncate $ (fromIntegral hw) / (fromIntegral (1 + n))
	w = truncate $ dww / (2.0 * dhl)
	dww = fromIntegral ww :: Double
	dhl = fromIntegral hl :: Double
	hl = 1 + (length levels)
	levels = tail (getLevels l)

getOutputWires :: Int -> Int -> [GateLevel] -> [(Point, Point)]
getOutputWires ww hw l
	= zip start end
    where
	start = zip (repeat ww) [eps, 2*eps .. n * eps]
	end = zip (repeat $ ww -w) [eps, 2*eps .. n * eps]
	n = length . last . getLevels $ l
	eps = truncate $ (fromIntegral hw) / (fromIntegral (1 + n))
	w = truncate $ dww / (2.0 * dhl)
	dww = fromIntegral ww :: Double
	dhl = fromIntegral hl :: Double
	hl = 1 + (length levels)
	levels = tail (getLevels l)

getMidWires :: Int -> Int -> [GateLevel] -> [(Point, Point)]
getMidWires ww hw l = build gateInputs gateOutputs
    where
	grep = getGateRepresentation ww hw l
	gateInputs = concat . map inputs $ grep
	gateOutputs = iw ++ (map outputs $ grep)
	iw = zip (getLevel0 l) (map snd (getInputWires ww hw l))
	build [] outp = []
	build (inp:inps) outp = (snd inp, snd ind) : (build inps outp)
	    where
		ind = head (dropWhile f outp)
		f outg = (fst outg) /= (fst inp)

getGateRepresentation :: Int -> Int -> [GateLevel] -> [Gate]
getGateRepresentation ww hw l = obtainGates ww hw wg hg l levels
	where
	    eps = 0.2
	    levels = tail (getLevels l)
	    vl = maximum . map length $ levels
	    hl = 1 + (length levels)
	    dvl = fromIntegral vl :: Double
	    dhl = fromIntegral hl :: Double
	    dhw = fromIntegral hw :: Double
	    dww = fromIntegral ww :: Double
	    hg = truncate $ dhw / (dvl + eps * (dvl + 1.0))
	    wg = truncate $ dww / (2.0 * dhl)

obtainGates :: Int -> Int -> Int -> Int -> [GateLevel] -> [[String]] -> [Gate]
obtainGates _ _ _ _ _ [] = []
obtainGates ww hw w h ioP l@(g:gs) = (newrow g) ++ (obtainGates ww hw w h ioP gs)
    where
	vl = length g
	freespace = hw - vl * h
	ispace = truncate $ (fromIntegral freespace) / (fromIntegral vl + 1.0)
	x = ww - 2 * (length l) * w
	newrow [] = []
	newrow (gate1:[]) = [Gate (x, ispace) w h (getInputsofGate gate1 ispace)
			    (getOutputsofGate gate1 ispace) (getDrawerofGate gate1)]
	newrow (gate1:l@(gate2:gates)) = (Gate (x, ispace + h + old) w h
			    (getInputsofGate gate1 (ispace + h + old)) 
			    (getOutputsofGate gate1 (ispace + h + old))
			    (getDrawerofGate gate1)) : (newrow l)
		    where
			old = snd (corner (head (newrow l)))
	getInputsofGate g y = zip invars inPoints
	    where
		gr = head . dropWhile (\x -> g /= (glValue x)) $ ioP
		invars = glVars gr
		numInVars = length invars
		inPoints = zip (repeat x) [y + eps, y + 2*eps .. y + numInVars*eps]
		eps = truncate $ (fromIntegral h) / (fromIntegral (numInVars + 1))
	getOutputsofGate g y = (g, ((x + w), (y + (truncate $ (fromIntegral h/2)))))
	getDrawerofGate gatetodraw = case glType realGate of
		    "AND" -> drawAndGate
		    "OR" -> drawOrGate
		    "XOR" -> drawXorGate
		    _ -> undefined
		where
		    realGate = head (drop index ioP)
		    index = locate gatetodraw ioP
		    locate g [] = error (g ++ " not found")
		    locate g (x:xs) = 
			    if g == (glValue x)
			    then 0
			    else 1 + locate g xs

