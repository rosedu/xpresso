module LogicGate where

import Graphics.UI.Gtk
import Control.Monad (mapM_)

-- variables and wire ends positions
type VarPair = (String, Point)

data Gate 
    = Gate {
	    corner  :: Point,
	    width   :: Int,
	    height  :: Int,
	    inputs  :: [VarPair],
	    outputs :: VarPair,
	    drawer  :: DrawWindow -> GC -> Gate -> (Int, Int, Int) -> IO()
    }

printGate :: Gate -> String
printGate g = (show . corner $ g) ++ " " ++ (show . width $ g) ++ " " ++
	(show . height $ g) ++ " " ++ (show . inputs $ g) ++ " " ++ (show . outputs $ g)

printGates :: [Gate] -> String
printGates = concat . map printGate

drawWires :: DrawWindow -> GC -> [(Point, Point)] -> IO ()
drawWires = drawSegments 

drawGates :: DrawWindow -> GC -> [Gate] -> IO ()
drawGates win gc = mapM_ (drawGate win gc)

drawGate :: DrawWindow -> GC -> Gate -> IO ()
drawGate win gc g = do
    let p@(iow, xg, wg) = getParams (fst . corner $ g) (width g)
    (drawer g) win gc g p

getParams :: Int -> Int -> (Int, Int, Int)
getParams x w = (iow, xg, wg) where
	k = 2
	iow = w `div` (k + 2)
	xg = x + iow
	wg = w - 2 * iow

debug :: DrawWindow -> GC -> Int -> Int -> Int -> Int -> IO()
debug win gc x y w h= do
    gcSetValues gc $ newGCValues {
	foreground = Color 0 0 65535
    }
    drawRectangle win gc False x y w h
    gcSetValues gc $ newGCValues {
	foreground = Color 0 0 0
    }
    return ()

drawAndGate :: DrawWindow -> GC -> Gate -> (Int, Int, Int) -> IO()
drawAndGate win gc g p@(iow, xg, wg) = do
    let y = snd . corner $ g
    let h = height g
    let widthOfArc = xg - wg
    let woa = 2 * wg
    let f p = (p, (xg, snd p))
    let f' p = (p, (xg + wg, snd p))
    let list1 = map f (map snd (inputs g))
    let list2 =	[f' (snd (outputs g))]
    drawArc win gc False widthOfArc y woa h (-5760) 11520
    drawLine win gc (xg, y) (xg, y + h)
    drawSegments win gc (list1 ++ list2)
    return ()

drawOrGate :: DrawWindow -> GC -> Gate -> (Int, Int, Int) -> IO()
drawOrGate win gc g p@(iow, xg, wg) = do
    let k = 3
    let nwg = truncate $ (fromIntegral wg) / k
    let y = snd . corner $ g
    let h = height g
    let widthOfArc = xg - wg
    let widthOfArc' = xg - nwg
    let woa = 2 * wg
    let woa' = 2 * nwg
    let f p = (p, (xg, snd p))
    let f' p = (p, (xg + wg, snd p))
    let list1 = map f (map snd (inputs g))
    let list2 =	[f' (snd (outputs g))]
    drawArc win gc False widthOfArc y woa h (-5760) 11520
    drawArc win gc False widthOfArc' y woa' h (-5760) 11520
    drawSegments win gc (list1 ++ list2)
    return ()

drawXorGate :: DrawWindow -> GC -> Gate -> (Int, Int, Int) -> IO()
drawXorGate win gc g p@(iow, xg, wg) = do
    let k = 3
    let delta = truncate $ (fromIntegral wg) / k / 2
    let nwg = truncate $ (fromIntegral wg) / k
    let y = snd . corner $ g
    let h = height g
    let xOfArc = xg - wg
    let xOfArc' = xg - nwg
    let xOfArc'' = xOfArc' - delta
    let woa = 2 * wg
    let woa' = 2 * nwg
    let f p = (p, (xg, snd p))
    let f' p = (p, (xg + wg, snd p))
    let list1 = map f (map snd (inputs g))
    let list2 =	[f' (snd (outputs g))]
    drawArc win gc False xOfArc y woa h (-5760) 11520
    drawArc win gc False xOfArc' y woa' h (-5760) 11520
    drawArc win gc False xOfArc'' y woa' h (-5760) 11520
    drawSegments win gc (list1 ++ list2)
    return ()
